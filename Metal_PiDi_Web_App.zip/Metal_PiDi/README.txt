# Metal PiDi — udhëzime nga telefoni Android

Ky është një prototip web në italisht/shqip që lidhet me projektin Supabase.

## 1. Çfarë përmban
- Regjistrim dhe hyrje me email/fjalëkalim.
- Regjistrim i totalit të orëve për një datë.
- Përditësim i orëve nëse e njëjta datë ruhet përsëri.
- Përmbledhje mujore.
- Panel i pronarit për totalet mujore të punëtorëve.
- Përdor RLS të Supabase për ndarjen e të dhënave.

## 2. Si ta hapësh
Hape `index.html` në një shfletues për provë, por hyrja e sigurt kërkon publikim në HTTPS. Për përdorim real, publikoje në një host statik falas si GitHub Pages ose Netlify.

## 3. Konfigurimi
Kur hapet faqja, vendos:
- Project URL nga Supabase → Project Settings → API.
- Çelësin publik `anon` / `publishable` nga i njëjti seksion.

Mos vendos `service_role` key në këtë faqe. Çelësi publik është menduar për klientin, por siguria varet nga politikat RLS.

## 4. Roli i pronarit
Regjistro fillimisht llogarinë e pronarit nga faqja. Pastaj në Supabase → SQL Editor, ekzekuto këtë komandë duke zëvendësuar EMAIL_PRONARIT me email-in e saktë:
```sql
update public.profiles
set role = 'owner'
where id = (
  select id from auth.users
  where lower(email) = lower('EMAIL_PRONARIT')
);
```
Kontrollo që vetëm një llogari e besuar të ketë rolin `owner`. Mos e vendos këtë komandë në faqen publike dhe mos lejo përdoruesit ta ekzekutojnë vetë.

## 5. Kufizime të rëndësishme
- Ky është version fillestar; testo me llogari provë përpara përdorimit real.
- Nëse email confirmation është aktiv, përdoruesi duhet të konfirmojë email-in para hyrjes.
- Vetëm pronari i caktuar manualisht mund të shohë panelin e pronarit.
- Për një prodhim më të plotë duhen edhe proces administrimi i punëtorëve, eksporti i raporteve dhe teste shtesë sigurie.
